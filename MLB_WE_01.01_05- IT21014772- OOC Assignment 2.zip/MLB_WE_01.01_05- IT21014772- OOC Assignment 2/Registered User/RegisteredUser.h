class RegisteredUser
{
	protected:
		char firstName[20];
		char lastName[20];
		char country[10];
		char address[50];
		char dateOfBirth[10];
		char email[20];
		int mobilenumber;
		char username[10];
		char password[20];

	private:
		int customerID;

	public:
		Registereduser();
		void userDetails(char fname[], char lname[], char cntry[], char addr[], char dob[], char mail[], int mno);
		void displayUserDetails();
		~Registereduser();
};
