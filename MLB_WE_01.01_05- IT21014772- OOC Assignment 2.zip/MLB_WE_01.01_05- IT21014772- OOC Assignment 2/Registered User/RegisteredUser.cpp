#include "RegisteredUser.h"
#include <iostream>
#include <cstring>
using namespace std;

RegisteredUser::RegisteredUser(){
	strcpy_s(firstName, "");
	strcpy_s(lastName, "");
	strcpy_s(country, "");
	strcpy_s(address, "");
	strcpy_s(dateOfBirth, "");
	strcpy_s(email, "");
	mobilenumber = 0;
	strcpy_s(username, "");
	strcpy_s(password, "");
	customerID = 0;
}

void RegisteredUser::userDetails(char fname[], char lname[], char cntry[], char addr[], char dob[], char mail[], int mno){
	strcpy_s(firstName, fname);
	strcpy_s(lastName, lname);
	strcpy_s(country, cntry);
	strcpy_s(address, addr);
	strcpy_s(dateOfBirth, dob);
	strcpy_s(email, mail);
	mobilenumber = mno;
}

void RegisteredUser::displayUserDetails(){
	cout << "User Details: " << endl << "First Name: " << firstName << endl << "Last Name: " << lastName << endl;
	cout << "Country: " << country << endl << "Address: " << address << endl << "Date of Birth: " << dateOfBirth << endl;
	cout << "E-mail: " << email << endl << "Mobile Number: " << mobilenumber << endl;
}

char RegisteredUser::getUsername(){
	return username[9];
}

char RegisteredUser::getPassword(){
	return password[19];
}

RegisteredUser::~RegisteredUser()
{
	cout << "object deleted";
}
