#include "RegisteredUser.h"
#include <iostream>
#include <cstring>
int main()
{
	RegisteredUser * user1; 
	
	user1 = new RegisteredUser();
	
	delete user1;
	
	return 0;
}
