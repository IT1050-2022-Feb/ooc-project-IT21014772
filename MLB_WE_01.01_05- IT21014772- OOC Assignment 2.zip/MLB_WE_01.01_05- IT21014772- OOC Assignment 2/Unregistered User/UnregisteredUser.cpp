#include "UnregisteredUser.h"
#include <iostream>
#include <cstring>
using namespace std;

void UnregisteredUser::getRegistered()
{
	user = new RegisteredUser[];
}
