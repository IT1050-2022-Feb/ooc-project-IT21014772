#include "RegisteredUser.h"
class UnregisteredUser
{
	private:
		RegisteredUser* user; 	
	
	public:
		void getRegistered();
};
